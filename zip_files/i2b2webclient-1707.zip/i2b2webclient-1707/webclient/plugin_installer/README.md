# dev-PLUGINS-i2b2-catalog
Software for displaying all the i2b2 community plug-ins available for installation
